# SPDX-PackageName: 2ping
# SPDX-PackageSupplier: Ryan Finnie <ryan@finnie.org>
# SPDX-PackageDownloadLocation: https://forge.colobox.com/rfinnie/2ping
# SPDX-FileCopyrightText: © 2010 Ryan Finnie <ryan@finnie.org>
# SPDX-License-Identifier: MPL-2.0

import time
import unittest


class TestPython(unittest.TestCase):
    def test_monotonic(self):
        val1 = time.monotonic()
        val2 = time.monotonic()
        self.assertGreaterEqual(val2, val1)
